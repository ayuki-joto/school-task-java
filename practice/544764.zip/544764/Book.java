/*
544764
Ayuki joto
*/

public class Book{
	String title;
	String authors;
	String publisher;
	Integer publishYear;

}