/*
544764
Ayuki joto
*/

public class User{
	String name;
	String gender;
	Integer age;
		
}
		
